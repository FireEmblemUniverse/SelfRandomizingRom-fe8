=====================================================
        ~ PHANTOM ANIMATION PACKAGE: VER 1.0 ~
=====================================================

A GBA FE battle animation by The Blind Archer

Tested and functional in both FE7 and FE8 (NTSC versions)

~ Scripting and Layout by:
Super Dancing Kitty (Melee attack)
Temp (Melee critical, Dodge, Handaxe)

~ Additional support by:
Archibald (Testing)
BwdYeti (Animation feedback)

~ Usage:
Because this package was made to finish an incomplete
class in Fire Emblem: The Sacred Stones, the Phantom
battle animation is considered Open Source by the creator.

Users are free to implement or adjust this animation as
they deem fit.

Ver. 1.0 finalized on 11/3/2013

Ver. 1.2 finalized on 07/31/2014 - Dancer_A